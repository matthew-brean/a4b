/*******************************************************************************
* Created by: Matthew Brean
* Created on: 2016-10-30
* Created for: ICS4U
* Assignment: 4b
* Triangle main stub
*******************************************************************************/

package a4;
import java.util.Scanner;

public class triangle {

	public static void main(String[] args) {
		Scanner SCAN=new Scanner(System.in);

		System.out.print("Length 1:");
		double s1=SCAN.nextDouble();
		System.out.print("Length 2:");
		double s2=SCAN.nextDouble();
		System.out.print("Length 3:");
		double s3=SCAN.nextDouble();
		
		//u means units
		TriangleClass triangle=new TriangleClass(s1,s2,s3);
		System.out.print("Triangle Area: "+triangle.getArea()+" u^2\n");
		System.out.print("Triangle Name: "+triangle.getName()+"\n");
		System.out.print("Triangle Height: "+triangle.getHeight()+" u\n");
		System.out.print("Triangle's Largest Inscribed Circle Radius: "+triangle.getCircleR()+" u\n");
		System.out.print("Triangle's Circumcircle's Area: "+triangle.getCircleA()+" u^2\n");
	}
}