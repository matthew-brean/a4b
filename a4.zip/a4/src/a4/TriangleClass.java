/*******************************************************************************
* Created by: Matthew Brean
* Created on: 2016-10-30
* Created for: ICS4U
* Assignment: 4b
* Triangle class
*******************************************************************************/

package a4;

import java.util.Arrays;

public class TriangleClass {
	//privates
	private double[] _sides=new double[3];
	private double _perimeter;
	private double _semiPerimeter;
	private double _area;
	private double _height;
	private String _name;
	private double _circleR;
	private double _circumA;
	
	public TriangleClass(double s1,double s2,double s3){
		this._sides[0]=s1;
		this._sides[1]=s2;
		this._sides[2]=s3;
		Arrays.sort(this._sides);
		
		if (IsTriangleValid()==true){
			this._perimeter=this._sides[0]+this._sides[1]+this._sides[2];
			this._semiPerimeter=this._perimeter/2;
			
			if ((this._sides[0]==this._sides[1])&&(this._sides[1]==this._sides[2])){
				this._name="Equilateral";				
			}
			else if ((this._sides[0]==this._sides[1])||(this._sides[1]==this._sides[2])||(this._sides[0]==this._sides[2])){
				this._name="Isoceles";				
			}
			else{
				this._name="Scalene";
			}

		double s=this._semiPerimeter;//making the following calculations less convoluted
		this._area=Math.sqrt(s*(s-this._sides[0])*(s-this._sides[1])*(s-this._sides[2]));
		this._height=(2*this._area)/this._sides[2];
		this._circleR=this._area/s;
		double circumR=(this._sides[0]*this._sides[1]*this._sides[2])/(this._area*4);
		this._circumA=Math.PI*Math.pow(circumR,2);
		}
		else
			System.out.println("-1");
		
	}
		protected boolean IsTriangleValid(){
			if((this._sides[0]+this._sides[1])>this._sides[2])
				return true;
			else
				return false;
		}
		
		//good lazy programmer
		public double getArea(){return this._area;}
		public String getName(){return this._name;}
		public double getHeight(){return this._height;}
		public double getCircleR(){return this._circleR;}
		public double getCircleA(){return this._circumA;}		
}
